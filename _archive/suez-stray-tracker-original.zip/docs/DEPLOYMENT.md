# Suez Stray Tracker — Complete Deployment Guide

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│  Mobile App (Expo / React Native)                               │
│  iOS + Android · EN/AR · Google Maps                           │
└──────────────────────┬──────────────────────────────────────────┘
                       │ HTTPS
┌──────────────────────▼──────────────────────────────────────────┐
│  Supabase (Backend-as-a-Service)                                │
│                                                                  │
│  ┌─────────────┐  ┌──────────┐  ┌─────────────┐  ┌──────────┐ │
│  │ PostgreSQL  │  │   Auth   │  │   Storage   │  │ Realtime │ │
│  │ + PostGIS   │  │ (JWT)    │  │ (dog photos)│  │ (ws)     │ │
│  └─────────────┘  └──────────┘  └─────────────┘  └──────────┘ │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ Edge Functions (Deno)                                    │  │
│  │  • notify-whatsapp  → Twilio WhatsApp API               │  │
│  │  • send-report      → Resend (weekly email)             │  │
│  │  • Cron job: every Monday 08:00 Cairo time              │  │
│  └──────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────────────────────┐
│  Admin Dashboard (React + Vite)                                 │
│  Deployed on Vercel · Service role access                       │
└─────────────────────────────────────────────────────────────────┘
```

---

## Step 1 — Supabase project setup

1. Create a project at https://supabase.com/dashboard
2. Go to **SQL Editor** and run `supabase/migrations/001_initial_schema.sql`
3. Go to **Storage** → New bucket → Name: `dog-photos` → Public: **yes**
4. Add Storage policy: allow all reads (public), allow authenticated inserts

### Storage bucket policy
```sql
-- Public read
create policy "public_read" on storage.objects for select using (bucket_id = 'dog-photos');
-- Authenticated upload
create policy "auth_upload" on storage.objects for insert with check (
  bucket_id = 'dog-photos' and auth.uid() is not null
);
-- Own delete
create policy "own_delete" on storage.objects for delete using (
  bucket_id = 'dog-photos' and owner = auth.uid()
);
```

---

## Step 2 — Environment variables

### Mobile app (`.env` in `mobile/`)
```
EXPO_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=eyJ...your_anon_key...
EXPO_PUBLIC_GOOGLE_MAPS_API_KEY=AIzaSy...your_maps_key...
```

### Admin dashboard (`.env` in `admin/`)
```
VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
VITE_SUPABASE_SERVICE_KEY=eyJ...your_service_role_key...
```
> ⚠️ The service key is secret — admin dashboard should be behind auth or VPN access only.

### Supabase Edge Function secrets
Run these via the Supabase CLI:
```bash
supabase secrets set TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
supabase secrets set TWILIO_AUTH_TOKEN=your_auth_token
supabase secrets set TWILIO_WHATSAPP_FROM=whatsapp:+14155238886
supabase secrets set WHATSAPP_NOTIFY_NUMBER=+201XXXXXXXXX
supabase secrets set RESEND_API_KEY=re_xxxxxxxxxxxxxxxx
```

---

## Step 3 — Deploy Edge Functions

```bash
# Install Supabase CLI
npm install -g supabase

# Login and link to your project
supabase login
supabase link --project-ref YOUR_PROJECT_REF

# Deploy functions
supabase functions deploy notify-whatsapp
supabase functions deploy send-report
```

### Set up the webhook (notify-whatsapp on sightings insert)
In Supabase dashboard → Database → Webhooks → New webhook:
- Name: `on_sighting_created`
- Table: `sightings`
- Events: `INSERT`
- URL: `https://YOUR_PROJECT.supabase.co/functions/v1/notify-whatsapp`
- HTTP method: POST
- Add header: `Authorization: Bearer YOUR_ANON_KEY`

### Set up weekly cron job (send-report)
In Supabase dashboard → Database → Extensions → Enable `pg_cron`
```sql
select cron.schedule(
  'weekly-report',
  '0 6 * * 1',  -- Monday 06:00 UTC = 08:00 Cairo
  $$
    select net.http_post(
      url := 'https://YOUR_PROJECT.supabase.co/functions/v1/send-report',
      headers := '{"Authorization": "Bearer YOUR_ANON_KEY"}'::jsonb
    );
  $$
);
```

---

## Step 4 — Google Maps API key

1. Go to https://console.cloud.google.com
2. Create a project → Enable **Maps SDK for Android** and **Maps SDK for iOS**
3. Create an API key → Restrict to your app's bundle ID
4. Add to `.env` as `EXPO_PUBLIC_GOOGLE_MAPS_API_KEY`

In `mobile/app.json`:
```json
{
  "expo": {
    "android": {
      "config": { "googleMaps": { "apiKey": "YOUR_KEY" } }
    },
    "ios": {
      "config": { "googleMapsApiKey": "YOUR_KEY" }
    }
  }
}
```

---

## Step 5 — Expo mobile app

```bash
cd mobile
npm install

# Development
npx expo start

# Production build (requires EAS account — free tier ok)
npm install -g eas-cli
eas login
eas build:configure
eas build --platform all
```

### Push notifications setup
In `mobile/app.json`, ensure:
```json
{
  "expo": {
    "plugins": [
      ["expo-notifications", {
        "icon": "./assets/notification-icon.png",
        "color": "#C8860A",
        "sounds": ["./assets/notification.wav"]
      }]
    ]
  }
}
```

For iOS: configure APNs in Apple Developer Console.
For Android: configure FCM in Firebase Console, add `google-services.json`.

---

## Step 6 — Admin dashboard

```bash
cd admin
npm create vite@latest . -- --template react-ts
npm install @supabase/supabase-js
npm run dev  # local

# Deploy to Vercel
vercel --prod
```

Protect the admin dashboard:
- Set Vercel Password Protection, OR
- Add Supabase Auth middleware that checks `role = 'admin'`

---

## Step 7 — App Store submission

### Android (Google Play)
```bash
eas build --platform android --profile production
eas submit --platform android
```

### iOS (App Store)
```bash
eas build --platform ios --profile production
eas submit --platform ios
```

Required App Store info:
- Category: Utilities
- Privacy policy URL: host a simple one at `/privacy`
- Description: mention community use, no personal data sold

---

## Step 8 — First admin user

After first signup, promote yourself to admin:
```sql
update profiles set role = 'admin' where id = 'your-user-uuid';
```

---

## Ongoing maintenance

| Task | Frequency | How |
|------|-----------|-----|
| Weekly email report | Automatic | Cron job (Step 3) |
| DB backup | Daily | Supabase auto-backups |
| Review sightings | Daily | Admin dashboard → Alerts |
| Export dogs data | Monthly | Admin dashboard → Export CSV |
| Push notification | Ad-hoc | Admin dashboard → Send Notification |
| Update zone boundaries | Rare | SQL update to zones.boundary |

---

## Cost estimate

| Service | Cost |
|---------|------|
| Supabase Pro | ~$25/mo (500MB DB, 5GB storage, realtime) |
| Vercel (admin) | Free |
| Expo EAS Build | Free (30 builds/month) or $29/mo unlimited |
| Google Maps | Free (28,500 mobile loads/month) |
| Twilio WhatsApp | ~$0.005/message |
| Resend (email) | Free (3,000 emails/month) |
| **Total** | **~$30-60/month** |

For a small city rescue org, Supabase free tier (with 500MB limit) may suffice initially.

---

## Security checklist

- [x] RLS enabled on all tables
- [x] Service key only in admin (server-side), never in mobile app
- [x] Photos served from public CDN (no signed URLs needed since public data)
- [x] Auth tokens stored in Expo SecureStore (encrypted keychain)
- [x] Admin dashboard access restricted
- [x] Dog location data is public (intentional — community tracking)
- [x] User emails never exposed in public queries (only display_name)
