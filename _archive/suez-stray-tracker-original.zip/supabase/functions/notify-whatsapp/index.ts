// supabase/functions/notify-whatsapp/index.ts
// Triggered via webhook when a new sighting is inserted
// Sends WhatsApp (Twilio) + Expo push notifications

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const TWILIO_ACCOUNT_SID  = Deno.env.get("TWILIO_ACCOUNT_SID")!;
const TWILIO_AUTH_TOKEN   = Deno.env.get("TWILIO_AUTH_TOKEN")!;
const TWILIO_WHATSAPP_FROM = Deno.env.get("TWILIO_WHATSAPP_FROM")!; // e.g. "whatsapp:+14155238886"
const WHATSAPP_GROUP_TO   = Deno.env.get("WHATSAPP_NOTIFY_NUMBER")!; // coordinator number
const EXPO_PUSH_URL       = "https://exp.host/--/api/v2/push/send";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

serve(async (req) => {
  try {
    const payload = await req.json();
    const { record: sighting } = payload; // INSERT webhook

    // Fetch zone name + reporter name
    const { data: zone } = await supabase
      .from("zones")
      .select("name_en, name_ar")
      .eq("id", sighting.zone_id)
      .single();

    const { data: reporter } = await supabase
      .from("profiles")
      .select("display_name, phone")
      .eq("id", sighting.reported_by)
      .single();

    const urgencyEmoji = {
      low: "👁️", medium: "⚠️", high: "🔴", critical: "🚨"
    }[sighting.urgency] ?? "👁️";

    const msgEN = `${urgencyEmoji} *New Sighting — ${zone?.name_en}*\n` +
      `Dogs seen: ~${sighting.count}\n` +
      `${sighting.description ?? ""}\n` +
      `Reported by: ${reporter?.display_name}\n` +
      `🗓️ ${new Date().toLocaleString("en-GB", { timeZone: "Africa/Cairo" })}`;

    // 1. Send WhatsApp via Twilio (only for medium+ urgency)
    if (["medium", "high", "critical"].includes(sighting.urgency)) {
      const twilioRes = await fetch(
        `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/Messages.json`,
        {
          method: "POST",
          headers: {
            "Authorization": "Basic " + btoa(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`),
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: new URLSearchParams({
            From: TWILIO_WHATSAPP_FROM,
            To: `whatsapp:${WHATSAPP_GROUP_TO}`,
            Body: msgEN,
          }),
        }
      );
      if (!twilioRes.ok) {
        console.error("Twilio error:", await twilioRes.text());
      }
    }

    // 2. Fetch all push tokens
    const { data: tokens } = await supabase
      .from("push_tokens")
      .select("token");

    if (tokens && tokens.length > 0) {
      const messages = tokens.map(({ token }) => ({
        to: token,
        title: `${urgencyEmoji} New sighting — ${zone?.name_en}`,
        body: sighting.description
          ? sighting.description.substring(0, 100)
          : `~${sighting.count} dog(s) spotted`,
        data: {
          type: "sighting",
          sighting_id: sighting.id,
          zone_id: sighting.zone_id,
          urgency: sighting.urgency,
        },
        sound: sighting.urgency === "critical" ? "default" : undefined,
        priority: ["high", "critical"].includes(sighting.urgency) ? "high" : "normal",
      }));

      // Expo accepts batches of up to 100
      const chunks = [];
      for (let i = 0; i < messages.length; i += 100) {
        chunks.push(messages.slice(i, i + 100));
      }

      for (const chunk of chunks) {
        await fetch(EXPO_PUSH_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(chunk),
        });
      }
    }

    // 3. Log notification in DB
    await supabase.from("notifications").insert({
      title: `${urgencyEmoji} New sighting — ${zone?.name_en}`,
      body: sighting.description ?? `~${sighting.count} dog(s) spotted`,
      data: { type: "sighting", sighting_id: sighting.id },
    });

    return new Response(JSON.stringify({ ok: true }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error(err);
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
});
